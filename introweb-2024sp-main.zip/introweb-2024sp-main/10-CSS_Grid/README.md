## Day 13

* Remaining midterm presentations

* CSS Grid in practice

* In-class work

### Homework

* You should be making major progress on your midterm; next class is the last time we are meeting before you submit them.

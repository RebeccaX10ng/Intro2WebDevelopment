/*
  NOTE:
  In Javascript you can comment a single line with two slashes,
  or create a block-comment with this slash+asterisk syntax.
*/

//////////////////// Console + Alert ////////////////////

//// sending messages to the developers console
// console.log("Hello!"); //included a string in quotation marks

//// Popping open an alert window
// alert("Le Boo~");

//////////////////// Variables / Types ////////////////////

/*
  What is a variable?
  a place to store data:
  string, integers (whole numebrs) & floats(decimal), boolean(true/false)
*/

//// defining variables
//// string: uses quotation marks to literally mark a string

let firstName = "Lil";
let lastName = "Ghostie";
let space = " :) ";

let concatString = firstName + " ~ :( ~ " + lastName;

//
// //// concatinating variables
//
// console.log(firstName);
// console.log(firstName + lastName); //option 1 for creating a space
// console.log(firstName, lastName); //option 2
// console.log(firstName + space + lastName); //option 3
// console.log(concatString);
//
// //// storing integers
//
let num1 = 5;
//
// //// storing floats
//
let num2 = 5.4;
let num3 = 4;
// console.log("The result is: " + (num1 + num2 + num3));
//
// //// 55.44-concatination if we don't use parenthesis
// //// 59.4-math if parenthesis are added to num2 + num3
//
// /*
//   math:
//   addition +
//   subtraction -
//   multiply *
//   divide /
// */
//
// //////////////////// Arrays ////////////////////
//
// //// creating arrays
// //// what is an array? an array is a COLLECTION of items
//
// /*
//   NOTE:
//   Items in an array are referenced by their "index"
//   which starts at ZERO, not ONE.
// */
//
let firstArray = ["Lil", "Big", "DJ", "Dr.", "Dark", "Social"];
// let secondArray = ["Boo", "Pumpkin", "Xan", "Kitten", "Girlboss", "Zoom", "Nook"];
//
// Print entire array...
// console.log(firstArray); //console log of the full array
// console.log(secondArray);
//
// //// Print one item from the array...
// console.log(firstArray[3]);
// console.log(secondArray[4]);
// //DJ
// //Dr. Distancing
//
// //////////////////// LOGIC with CONDITIONALS ////////////////////
//
/*
  Set up control flow with if/else statements
  < or >
  <= or >=
*/
//
// //// js accepts equality as == or ===. When you use === you are ensureing TRUE equality.
//
let num = 1;
// num = 55;
//

// if (num == 15){
//    console.log('you have the correct number!');
// } else if (num > 15){
//    console.log('your number is too big');
// } 
// else {
//    console.log('please choose another number');
// }





//
// //////////////////// FUNCTIONS ////////////////////
//
// /*
//   There are many functions in JavaScript for modifying values, math, etc...
// */

// Random FLOAT from 0-1
// console.log(Math.random());

//// Random FLOAT from 0-50
// console.log(Math.random() * 50);
//
//// Random INTEGER from 0-length of an array, giving us an INDEX...
var secondArray = ["Animal Crossing", "Pumpkin", "Ghost", "Zoom Party", "Toilet Paper", "Yoga", "Netflix Party", "Bops"];
var randomIndex = Math.floor( Math.random() * secondArray.length );
// console.log(randomIndex);
//
// //// Random item from array using our random index
// console.log(secondArray[randomIndex]);
//
//
// //////////////////// CUSTOM FUNCTIONS ////////////////////
//
// /*
//   to make a procedure, set of instructions that make things easier
//   compartamentalize setting up a small machine that performs a simple procedure
// */
//
// //// Setting it up
//
function sayHello() {
    console.log('hellooooo!');
    console.log("🎃");
}
//
// //// Calling the function
//
// sayHello();

//
// //// Setting up a function with arguments / parameters
//

function addNumber(numberOne, numberTwo){
    console.log("Result: " + (numberOne + numberTwo));
}

//
// //// Calling the addNumber function
//
// addNumber(40, 70);
//
// //// RETURNING values from a function

function addNumberAndReturn(numberOne, numberTwo) {
    console.log("Ran the function...");
    return numberOne + numberTwo;
}
//
// console.log("Nice. " + addNumberAndReturn(400,20));
//
// //////////////////// LOGICAL OPERATORS ////////////////////
//
// /*
//   create a function that acts like a virtual door
//   if we call door #1, we will return Hall of Mirrors
//   if we call door #2, we will return Mummy Bathroom
//   if we call door #3, we will return Witchy Kitchen
// */
//
// //// function that contains an if/else statement
// //// test each of your doors by calling the function at least 3 times
//

function door(num){
  if (num == 1){
    return "Bathroom";
  }
  else if (num == 2){
    return "Bedroom";
  }
  else if (num == 3){
    return "Kitchen";
  }
  else {
    return "There are only 3 doors!";
  }
}
//
console.log(door(1));
console.log(door(2));
console.log(door(3));
console.log(door(5));

// var doorCheck = door(2);
// console.log(doorCheck);

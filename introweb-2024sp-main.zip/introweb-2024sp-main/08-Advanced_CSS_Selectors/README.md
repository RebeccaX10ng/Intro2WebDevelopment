## Day 9 (Week 5 class A)

* Advanced CSS Selectors

  * https://www.w3schools.com/cssref/css_selectors.asp

* If we have time: Begin advanced CSS typography rules

### Homework

* Experiment with advanced CSS selectors. You can just make a visual composition, a webpage, or apply the things we learned to a previous site you've made.

* Select your Design Reference (poster, bookcover, single frame design) that you will be recreating out of HTML.

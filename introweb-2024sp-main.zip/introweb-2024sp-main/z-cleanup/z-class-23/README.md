## Day 23

* Review [Final Project](https://github.com/IDMNYU/DM-UY-2193-A/blob/master/finalprojects.md) presentation criteria and order

* Final Project Workshop

### Reminders:

* ALL outstanding work must be turned in by 5pm on Thursday, May 9. This includes Learning Logs.

* There are no extensions on final projects, and the presentation is part of your grade.

* Moeezo will be holding her last day of office hours tomorrow, Friday, May 3.

### Homework

FINISH YOUR FINAL PROJECTS!!

```

 /\     /\
  {  `---'  }
  {  O   O  }
  ~~>  V  <~~
   \  \|/  /
    `-----'__
    /     \  `^\_
   {       }\ |\_\_   W
   |  \_/  |/ /  \_\_( )
    \__/  /(_E     \__/
      (  /
       MM
       
```
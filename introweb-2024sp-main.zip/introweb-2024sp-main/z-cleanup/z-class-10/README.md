## Day 10

* Check ins and review your chosen Design Reference

### Resources

* [CSS Tricks - Set Page Background to a Full Image](http://css-tricks.com/perfect-full-page-background-image/)
* [Little CSS Stuff Newcomers Get Confused ABout](http://css-tricks.com/little-css-stuff-newcomers-get-confused-about/)
* [CSS Positioning 101](http://alistapart.com/article/css-positioning-101)
* [The Holy Grail of CSS Centering](http://webdesign.tutsplus.com/tutorials/the-holy-grail-of-css-centering--cms-22114)


### Homework

* Complete the recreation of your design reference.

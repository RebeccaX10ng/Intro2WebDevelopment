- Games made by my students the last time we did this assignment: https://www.instagram.com/codenothing_637/

# EXPERIMENTAL / ARTGAMES

- “Magic Circle” - https://en.wikipedia.org/wiki/Magic_circle_(virtual_worlds)
- “Ludonarrative Dissonance” - https://en.wikipedia.org/wiki/Ludonarrative_dissonance

- [ ] Line Wobbler - https://www.youtube.com/watch?v=mLgtPKT1Q70 , https://www.youtube.com/watch?v=HRCQ0MJVpro
- [ ] Dys4ia (2012) - https://en.wikipedia.org/wiki/Anna_Anthropy
- [ ] Myst (1993) - https://www.youtube.com/watch?v=D30r0iRH73Q
- [ ] The Unfinished Swan
- [ ] Phone Story: https://www.youtube.com/watch?v=sSMSFLAsNzc
- [ ] Everything (maker of "Mountain"): https://www.youtube.com/watch?v=F43k_IDDrXA , https://www.youtube.com/watch?v=2e8w9W5bvV8 , https://www.youtube.com/watch?v=Dpzd-5sSYj4
- [ ] Getting Over It: https://www.youtube.com/watch?v=DCcA4FyWeXI , https://www.youtube.com/watch?v=a0nm_reRezA
- [ ] Chop Suey: https://www.youtube.com/watch?v=2toGOQx9sC0
- [ ] Seaman: https://www.youtube.com/watch?v=L1H1GAiFdis , https://www.youtube.com/watch?v=BAbZovMNZiQ
- [ ] Flower: https://www.youtube.com/watch?v=bzCbca1vfaA
- [ ] Journey: https://www.youtube.com/watch?v=bkL94nKSd2M1
- [ ] Universal Paperclips: https://en.wikipedia.org/wiki/Universal_Paperclips , https://www.decisionproblem.com/paperclips/
- [ ] Biophilia: https://www.youtube.com/watch?v=dikvJM__zA4 , https://www.youtube.com/watch?v=OrtCMQceyjA
- [ ] Bubsy 3d: Bubsy visits the James Turrell Retrospective: https://bubsy3d.com/ ,
- [ ] Sonic Dreams Collection - https://hedgehog.exposed/ , https://www.youtube.com/watch?v=Jd9pIR1hCJY , https://www.youtube.com/watch?v=LnVAguMh8bw&has_verified=1

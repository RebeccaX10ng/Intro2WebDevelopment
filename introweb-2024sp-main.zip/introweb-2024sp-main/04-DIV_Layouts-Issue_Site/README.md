## Week 3 - Class A

* See [slides.pdf](Slides-Web_03a.pdf) in this directory for in-class slides.

* See [in-class-demonstration](in-class-demonstration/) in this directory for the CSS I was demonstrating in class.

* Github Pages review.

* HTML questions that have emerged?

* The fundamentals of positioning and layout with CSS.
	* Box model, `display`, `box-sizing`, `width`/`height`, `position`, `margin`, `padding`, `top` / `left` etc...

### Homework

Using paper or design software “block out” a layout for a small three-page website.

Next homework, you will be turning this into a small website about an issue or cause you care about.

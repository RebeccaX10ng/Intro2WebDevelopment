## Week 4 Class B

* CSS Units

* The magic of viewport based sizing

* Full flexbox layout

### Homework

* Revise or re-create your 3 page website with extensive use of flexbox, and viewport based units where appropriate.
